<?php

$name = $_POST['name'];
$email = $_POST['email'];
$pwd = $_POST['pwd'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="l-form">
<form>
<h2>Details You Entered</h2>

<h4><?php echo $name; ?></h4>
<h4><?php echo $email; ?></h4>
<h4><?php echo $pwd; ?></h4>
</form>
</div>
</body>
</html>
<style>
        @import url("https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap");
    body{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        background: #fff;
        font-family: 'Roboto', sans-serif;
    }
    .l-form {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }
    form{
        width: 360px;
        padding: 4rem 2rem;
        border-radius: 1rem;
        box-shadow: 0 10px 25px rgba(92, 99, 105, .2);
    }
</style>